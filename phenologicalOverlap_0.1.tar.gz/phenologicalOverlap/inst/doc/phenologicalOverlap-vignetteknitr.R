## ---- eval=TRUE, warning=FALSE, message=FALSE----------------------------
# Load required packages
library(MASS)

# Load example data
data(mcycle)

hist(rnorm(100))

